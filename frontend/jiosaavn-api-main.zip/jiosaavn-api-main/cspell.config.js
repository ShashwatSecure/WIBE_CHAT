export default {
  version: '0.2',
  language: 'en',
  words: [
    'saavn',
    'sumit',
    'kolhe',
    'jiosaavn',
    'maxage',
    'asynciterable',
    'sumitkolhe',
    'kbps',
    'perma',
    'firstname',
    'lastname',
    'stationid'
  ],
  ignorePaths: ['**/node_modules/**', 'dist', 'coverage', '.vscode', 'CHANGELOG.md']
}
