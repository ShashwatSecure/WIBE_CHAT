export interface DownloadLink {
  quality: string
  url: string
}
