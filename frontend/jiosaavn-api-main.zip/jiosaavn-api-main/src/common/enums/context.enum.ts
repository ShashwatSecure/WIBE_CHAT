export enum ApiContextEnum {
  ANDROID = 'android',
  WEB6DOT0 = 'web6dot0'
}
